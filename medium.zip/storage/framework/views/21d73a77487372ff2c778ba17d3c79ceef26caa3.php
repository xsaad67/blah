<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">

<url>
  <loc><?php echo e(url("/")); ?></loc>
  <lastmod>2018-07-11</lastmod>
  <changefreq>monthly</changefreq>
  <priority>1.0</priority>
</url>


<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <url>
      <loc><?php echo e(url("/")."/category/".$category->slug); ?></loc>
      <lastmod><?php echo e($category->updated_at->format('Y-m-d')); ?></lastmod>
      <changefreq>monthly</changefreq>
      <priority>0.9</priority>
   </url>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <url>
      <loc><?php echo e(url("/")."/".$post->category->slug."/".$post->slug); ?></loc>
      <lastmod><?php echo e($post->updated_at->format('Y-m-d')); ?></lastmod>
      <changefreq>monthly</changefreq>
      <priority>0.9</priority>
   </url>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


 <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <url>
      <loc><?php echo e(url("/")."/author/".$user->slug); ?></loc>
      <lastmod><?php echo e($user->updated_at->format('Y-m-d')); ?></lastmod>
      <changefreq>monthly</changefreq>
      <priority>0.7</priority>
   </url>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</urlset> 
