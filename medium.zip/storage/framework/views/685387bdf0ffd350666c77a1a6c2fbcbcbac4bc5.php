<?php $__env->startSection('title',$count." results found for ". $query. ' | '. env('APP_NAME') ); ?>
<?php $__env->startSection('description',$count." results found for ". $query); ?>
<?php $__env->startSection('css'); ?>
<style>
  .listfeaturedtag h4.card-text, .listrecent h4.card-text {
    color: rgba(0,0,0,.44);
    font-size: 0.95rem;
    line-height: 1.4;
    font-weight: 400;
}
.alert-primary {
    color: #004085;
    background-color: #cce5ff;
    border-color: #b8daff;
}
.alert {
    position: relative;
    padding: .75rem 1.25rem;
    margin-bottom: 1rem;
    border: 1px solid transparent;
    border-radius: .25rem;
}
</style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="section-title">
	<h2><span class="title"><?php echo e($count." results found for ". $query); ?></span> </h2>
</div>

<div class="row listrecent">

<?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-4 grid-item d-flex align-items-stretch">
      <div class="card post tag-getting-started" >
      <a href="<?php echo e($post->link); ?>">
        <span class="wrapmaxheight">
            <img class="img-fluid img-thumb" src="<?php echo e($post->featuredMedia('medium')); ?>" style="height:250px; object-fit:cover; width:100%;">
        </span>
      
      </a>
      <div class="card-block card-body d-flex flex-column">
        <h2 class="card-title"><a href="<?php echo e($post->link); ?>"><?php echo e($post->title); ?></a></h2>
        <h4 class="card-text"><?php echo e(trucnateStringh($post->body)); ?></h4>
        <div class="metafooter mt-auto">
          <div class="wrapfooter">
            <a class="meta-footer-thumb" href="<?php echo e($post->user->link); ?>">
                  <img class="author-thumb" src="<?php echo e($post->user->dp); ?>" alt="<?php echo e($post->user->name); ?>}" />
            </a>
            <span class="author-meta">
            <span class="post-name">
              <a href=""><a href="<?php echo e($post->user->link); ?>"><?php echo e($post->user->name); ?></a></a></span><br/>
            <span class="post-date">
              <time class="post-date" datetime="<?php echo e($post->created_at); ?>"> <?php echo e($post->created_at->diffForHumans()); ?>  </time> 
            </span>
            <span class="dot">
              
            </span>
              <span class="readingtime"><?php echo e(wordToMinutes($post->body)); ?> min read</span>

            </span>
         
          </div>
        </div>
      </div>
    </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			
</div>

<div class="clearfix"></div>
<?php if($result->isEmpty()): ?>
<div class="row">
	
<div class="alert alert-primary mx-auto">
		Sorry we can't find result of your desired query instead you can look into our popular posts
</div>

</div>
<div class="row listrecent">
	
	<?php $__currentLoopData = \App\Post::popular(9)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


		<div class="col-md-4 grid-item d-flex align-items-stretch">
	      	<div class="card post tag-getting-started" >
		      <a href="<?php echo e($post->link); ?>">
		        <span class="wrapmaxheight">
		            <img class="img-fluid img-thumb" src="<?php echo e($post->featuredMedia('medium')); ?>" style="height:250px; object-fit:cover; width:100%;">
		        </span>
		      
		      </a>
		      <div class="card-block card-body d-flex flex-column">
		        <h2 class="card-title"><a href="<?php echo e($post->link); ?>"><?php echo e($post->title); ?></a></h2>
		        <h4 class="card-text"><?php echo e(trucnateStringh($post->body)); ?></h4>
		        <div class="metafooter mt-auto">
		          <div class="wrapfooter">
		            <a class="meta-footer-thumb" href="<?php echo e($post->user->link); ?>">
		                  <img class="author-thumb" src="<?php echo e($post->user->dp); ?>" alt="<?php echo e($post->user->name); ?>}" />
		            </a>
		            <span class="author-meta">
		            <span class="post-name">
		              <a href=""><a href="<?php echo e($post->user->link); ?>"><?php echo e($post->user->name); ?></a></a></span><br/>
		            <span class="post-date">
		              <time class="post-date" datetime="<?php echo e($post->created_at); ?>"> <?php echo e($post->created_at->diffForHumans()); ?>  </time> 
		            </span>
		            <span class="dot">
		              
		            </span>
		              <span class="readingtime"><?php echo e(wordToMinutes($post->body)); ?> min read</span>

		            </span>
		         
		          </div>
		        </div>
		      </div>
	    	</div>
		</div>



	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php endif; ?>




	



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>