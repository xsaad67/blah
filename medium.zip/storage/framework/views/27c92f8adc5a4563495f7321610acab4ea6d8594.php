<?php $__env->startSection('content'); ?>



<div class="container">


    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Create Post</div>

                <div class="panel-body">
                    <?php echo $__env->make('messages.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <form class="form-horizontal" method="POST" action="<?php echo e(action('BookmarkController@store')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label">Post Id</label>

                        <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="id" >
                            </div>
                        </div>

                     
                       

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Create Post
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>

<script src="<?php echo e(asset('ckeditor/ckeditor.js')); ?>"></script>

<script>
     CKEDITOR.replace( 'body' );
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>