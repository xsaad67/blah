<?php $__env->startSection('content'); ?>


<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="section-title">
    <h2>
    <span><?php echo e($category->name); ?> </span>
    <a class="d-block pull-right morefromcategory" href="/category/<?php echo e($category->slug); ?>">
        More &nbsp; <i class="fa fa-angle-right"></i>
    </a>
    <div class="clearfix"></div>
    </h2>
</div>

<?php if($loop->index%2 == 0): ?>

    <section class="featured-posts">
        <div class="row listfeaturedtag margneg10">
            <?php $__currentLoopData = $category->latestposts->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="col-md-6 col-lg-6 col-sm-6 padlr10">
                    <div class="card" id="post-<?php echo e(encrypt($post->id)); ?>">
                        <div class="row">
                            <div class="col-md-5 wrapthumbnail">
                                <a href="/<?php echo e($post->category->slug); ?>/<?php echo e($post->slug); ?>">
                                   <?php $__currentLoopData = $post->medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($media->fileType=='featured'): ?>
<div class="thumbnail" style="background-image:url(<?php echo e(asset('wp-content/uploads/'.$media->fileName)); ?>)"></div>
                                  
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </a>
                            </div>
                            <div class=" col-md-7 ">
                                <div class="card-block">
                                    <h2 class="card-title"> <a href="/<?php echo e($post->category->slug); ?>/<?php echo e($post->slug); ?>"><?php echo e(trucnateStringh($post->title,40)); ?></a></h2>
                                    <span class="card-text d-block">
                                        <?php echo e(trucnateStringh($post->body,100)); ?>


                                        <?php $bookmarkId = "" ?>
                                        <?php $__currentLoopData = $post->bookmarks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bookmark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($bookmark->user_id ==1 && $bookmark->post_id = $post->id): ?>

                                             <?php $bookmarkId = $bookmark->id ?>

                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                    </span>
                                    <div class="metafooter">
                                        <div class="wrapfooter">
                                            <span class="meta-footer-thumb">
                        <a href="/author/<?php echo e($post->user->slug); ?>">
                        <img alt='' src='<?php echo e(is_null($post->user->image)  ? asset("wp-content/uploads/user/default.png") :  asset("wp-content/uploads/user/".$post->user->image)); ?>' srcset='' class='avatar avatar-40 photo author-thumb' height='40' width='40' /> 
                         </a>
                    </span>
                    <span class="author-meta">
                        <span class="post-name">
                        <a href="/author/<?php echo e($post->user->slug); ?>"><?php echo e($post->user->name); ?></a></span><br>
                                            <span class="post-date"><?php echo e($post->created_at->diffForHumans()); ?></span>
                                            <span class="dot"></span>
                                            <span class="readingtime"><?php echo e(wordToMinutes($post->body)); ?> min read</span>
                                            </span>
                                         </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>

<?php else: ?>

    <div class="row listrecent">

                    <?php $__currentLoopData = $category->latestposts->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <?php $bookmarkId = "" ?>
                                            <?php $__currentLoopData = $post->bookmarks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bookmark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($bookmark->user_id ==1 && $bookmark->post_id = $post->id): ?>

                                                 <?php $bookmarkId = $bookmark->id ?>

                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($loop->first): ?>
                              
                    <div class="col-md-4 col-lg-4 col-sm-4 padr10" id="post-<?php echo e(encrypt($post->id)); ?>">
                        <div class="card post highlighted">

                            <a class="thumbimage" href="/<?php echo e($post->category->slug); ?>/<?php echo e($post->slug); ?>" style="<?php $__currentLoopData = $post->medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($media->fileType=='featured'): ?>
                                             background-image:url(<?php echo e(asset('wp-content/uploads/'.$media->fileName)); ?>)
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>"></a>
                            <div class="card-block">
                                <h2 class="card-title"><a href="/<?php echo e($post->category->slug); ?>/<?php echo e($post->slug); ?>"><?php echo e($post->title); ?></a></h2>
                                <span class="card-text d-block"><?php echo e(trucnateStringh($post->body,100)); ?></span>
                                <div class="metafooter">
                                    <div class="wrapfooter">
                        <span class="meta-footer-thumb">
                            <a href="/author/<?php echo e(unicodeSlug($post->user->name)); ?>">
                        <img alt='' src='<?php echo e(is_null($post->user->image)  ? asset("wp-content/uploads/user/default.png") :  asset("wp-content/uploads/user/".$post->user->image)); ?>' srcset='' class='avatar avatar-40 photo author-thumb' height='40' width='40' /> 
                         </a>
                         </span>
                                        <span class="author-meta">
                        <span class="post-name"><a href="author/themesforwebcom/index.html"><?php echo e($post->user->name); ?></a></span><br>
                                        <span class="post-date"><?php echo e($post->created_at->diffForHumans()); ?></span>
                                        <span class="dot"></span>
                                           <span class="readingtime"><?php echo e(wordToMinutes($post->body)); ?> min read</span>
                                    
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8 col-lg-8 col-sm-8">
                        <div class="row skipfirst">

                            <?php endif; ?>
                            
                            <div class="col-md-6 col-lg-6 col-sm-6 grid-item" id="post-<?php echo e(encrypt($post->id)); ?>">

                                <div class="card post height262">
                                    <a class="thumbimage" href="/<?php echo e($post->category->slug); ?>/<?php echo e($post->slug); ?>" style="<?php $__currentLoopData = $post->medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($media->fileType=='featured'): ?>
                                            background-image:url(<?php echo e(asset('wp-content/uploads/'.$media->fileName)); ?>)
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>"></a>
                                    <div class="card-block">
                                        <h2 class="card-title">
                                            <a href="/<?php echo e($post->category->slug); ?>/<?php echo e($post->slug); ?>"><?php echo e(trucnateStringh($post->title,40)); ?></a>
                                        </h2>
                                        <div class="metafooter">
                                            <div class="wrapfooter">
                                                 <span class="meta-footer-thumb">
                            <a href="/author/<?php echo e(unicodeSlug($post->user->name)); ?>">
                        <img alt='' src='<?php echo e(is_null($post->user->image)  ? asset("wp-content/uploads/user/default.png") :  asset("wp-content/uploads/user/".$post->user->image)); ?>' srcset='' class='avatar avatar-40 photo author-thumb' height='40' width='40' /> 
                         </a>
                         </span>
                                                <span class="author-meta">
                        <span class="post-name">
                        <a href="author/themesforwebcom/index.html"><?php echo e($post->user->name); ?></a></span><br>
                                                <span class="post-date"><?php echo e(\Carbon\Carbon::parse($post->created_at)->diffForHumans()); ?></span>
                                                <span class="dot"></span>
                                                <span class="readingtime"><?php echo e(wordToMinutes($post->body)); ?> min read</span>
                                                </span>
                                
                                    </div>
                                  </div>
                                    </div>
                                </div>
                            </div>

                            <?php if($loop->last): ?>

                        </div>
                    </div>
                            <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                 
                    <div class="clearfix"></div>

    </div>

<?php endif; ?>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>