<?php $__env->startSection('css'); ?>
<style>
body {
	padding-top:5rem;
}
.mainheading {
	padding:1rem 0rem;
}
a {
	color:#00ab6b;
}
a,a:hover {
	transition:all 0.2s;
}
.mediumnavigation {
	background:rgba(255,255,255,.97);
	box-shadow:0 2px 2px -2px rgba(0,0,0,.15);
}
section {
	margin-bottom:30px;
}
.section-title h2 {
	border-bottom:1px solid rgba(0,0,0,.15);
	margin-bottom:25px;
	font-weight:700;
	font-size:1.4rem;
	margin-bottom:27px;
}
.section-title span.title {
	border-bottom:1px solid rgba(0,0,0,.44);
	display:inline-block;
	padding-bottom:20px;
	margin-bottom:-1px;
}
@media (min-width:576px) {
	.card-columns.listfeaturedtag {
			-webkit-column-count:2;
			-moz-column-count:2;
			column-count:2;
	}
}
@media (min-width:992px) {
	.navbar-toggleable-md .navbar-nav .nav-link {
			padding-right:.7rem;
			padding-left:.7rem;
	}
}
.card-columns .card {
	margin-bottom:20px;
}
.listfeaturedtag .wrapthumbnail {
	height:258px;
	flex:0 0 auto;
}
.listfeaturedtag .card {
	border:1px solid rgba(0,0,0,.1);
	border-radius:2px;
	height:260px;
	padding-left:0;
	overflow:hidden;
	margin-bottom:15px;
}
.no-featured-image .listfeaturedtag .card {
	height:auto;
}
.listfeaturedtag .thumbnail {
	background-size:cover;
	height:100%;
	display:block;
	background-position:38% 22% !important;
	background-origin:border-box!important;
	border-top-left-radius:2px;
    position: relative;
}
.listfeaturedtag .card-block {
	padding-left:0;
}
.listfeaturedtag h2.card-title,.listrecent h2.card-title {
	font-size:1.3rem;
	font-weight:700;
	line-height:1.25;
}
.listfeaturedtag h2.card-title a,.listrecent h2.card-title a {
	color:rgba(0,0,0,.8);
}
.listfeaturedtag h2.card-title a:hover,.listrecent h2.card-title a:hover {
	color:rgba(0,0,0,.6);
	text-decoration:none;
}
.listfeaturedtag h4.card-text,.listrecent h4.card-text {
	color:rgba(0,0,0,.44);
	font-size:0.95rem;
	line-height:1.4;
	font-weight:400;
}
.listfeaturedtag .wrapfooter {
	position:absolute;
	bottom:15px;
	font-size:12px;
	display:block;
	width:85%;
}
.listrecent .wrapfooter {
	font-size:12px;
	margin-top:30px;
}
.listrecent .card {
	border-radius:2px;
}
.wrapmaxheight {
    max-height:300px;
    overflow:hidden;
    display: block;
}
@media (min-width:1024px) {
	.listrecent .card {
				min-height:530px;
	}
	.listrecent .card .metafooter {
			position:absolute;
			width:90%;
			bottom:20px;
	}
	.listrecent.listrelated .card {
			min-height:250px;
	}
	.listrecent.listrelated .card .metafooter {
			position:relative;
			width:auto;
			bottom:0;
	}
}
.listrecent .card .img-thumb {
	width:100%;
}
.author-thumb {
	width:40px;
	height:40px;
	float:left;
	margin-right:13px;
	border-radius:100%;
}
.post-top-meta {
	margin-bottom:2rem;
}
.post-top-meta .author-thumb {
	width:72px;
	height:auto;
}
.post-top-meta.authorpage .author-thumb {
	margin-top:40px;
}
.post-top-meta span {
	font-size:0.9rem;
	color:rgba(0,0,0,.44);
	display:inline-block;
}
.post-top-meta .author-description {
	margin-bottom:10px;
	margin-top:1rem;
	font-size:0.95rem;
}
.masonrygrid .author-meta {
	 width:70%;
}
span.post-name,span.post-date,span.author-meta {
	display:inline-block;
}
span.post-date,span.post-read {
	color:rgba(0,0,0,.44);
}
span.post-read-more {
	align-items:center;
	display:inline-block;
	float:right;
	margin-top:12px;
}
span.post-read-more a {
	color:rgba(0,0,0,.44);
}
span.post-name a,span.post-read-more a:hover {
	color:rgba(0,0,0,.8);
}
.dot:after {
	content:"Â·";
	margin-left:3px;
	margin-right:3px;
}
.mediumnavigation .form-control {
	font-size:0.8rem;
	border-radius:30px;
	overflow:hidden;
	border:1px solid rgba(0,0,0,0.04);
	 font-style:italic;
}
.mediumnavigation .form-inline {
	margin-left:15px;
}
.mediumnavigation .form-inline .btn {
	margin-left:-50px;
	border:0;
	border-radius:30px;
	cursor:pointer;
}
.mediumnavigation .form-inline .btn:hover,.mediumnavigation .form-inline .btn:active {
	background:transparent;
	color:green;
}
.mediumnavigation .navbar-brand {
	font-weight:500;
}
.mediumnavigation .dropdown-menu {
	border:1px solid rgba(0,0,0,0.08);
	margin:.5rem 0 0;
}
.mediumnavigation .nav-item,.dropdown-menu {
	font-size:0.9rem;
}
.mediumnavigation .search-icon {
	margin-left:-40px;
	display:inline-block;
	margin-top:3px;
	-webkit-appearance:none;
}
.mediumnavigation .navbar-brand img {
	max-height:30px;
	margin-right:5px;
}
.mainheading h1.sitetitle {
	font-family:Righteous;
}
.mainheading h1.posttitle {
	font-weight:700;
	margin-bottom:1rem;
}
.footer {
	border-top:1px solid rgba(0,0,0,.05)!important;
	padding-top:15px;
	padding-bottom:12px;
	font-size:0.8rem;
	color:rgba(0,0,0,.44);
	margin-top:50px;
}
.link-dark {
	color:rgba(0,0,0,.8);
}
.article-post {
	font-family:Merriweather;
	font-size:1.2rem;
	line-height:1.8;
	color:rgba(0,0,0,.8);
}
.page-template .article-post {
	font-family:-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif
}
blockquote {
	border-left:4px solid #00ab6b;
	padding:0 20px;
	font-style:italic;
	color:rgba(0,0,0,.5);
}
.article-post p,.article-post blockquote {
	margin:0 0 1.5rem 0;
}
.featured-image {
	display:block;
	margin:0px auto;
	margin-bottom:2rem;
}
.share {
	text-align:center;
	margin-top:20px;
}
.share p {
	margin-bottom:10px;
	font-size:0.95rem;
}
.share {
	display:none;
}
.share ul li {
	display:inline-block;
	margin-bottom:5px;
}
.share ul {
	padding-left:0;
	margin-left:0;
}
.svgIcon {
	vertical-align:middle;
}
@media (min-width:1024px) {
	.share {
			position:fixed;
			display:block;
	}
	.share ul li {
			display:block;
	}
}
@media (max-width:999px) {
	.listfeaturedtag .wrapthumbnail,.listfeaturedtag .col-md-7 {
			width:100%;
			max-width:100%;
			-webkit-box-flex:0;
			-webkit-flex:100%;
			-ms-flex:100%;
			flex:100%;
	}
	.listfeaturedtag .wrapthumbnail {
			height:250px;
	}
	.listfeaturedtag .card {
			height:auto;
	}
	.listfeaturedtag .wrapfooter {
			position:relative;
			margin-top:30px;
	}
	.listfeaturedtag .card-block {
			padding:20px;
	}
}
@media (max-width:1024px) {
	.post-top-meta .col-md-10 {
			text-align:center;
	}
}
@media (max-width:767px) {
	.post-top-meta.authorpage {
			text-align:center;
	}
}
.share,.share a {
	color:rgba(0,0,0,.44);
	fill:rgba(0,0,0,.44);
}
.graybg {
	background-color:#fafafa;
	padding:40px 0 46px;
	position:relative;
}
.listrelated .card {
	box-shadow:0 1px 7px rgba(0,0,0,.05);
	border:0;
}
.grid-item {
	padding-left:10px;
	padding-right:10px;
	margin-bottom:20px;
}
.card {
	border-radius:2px;
	transition:0.3s;
}
.card .img-thumb {
	border-top-right-radius:2px;
	border-top-left-radius:2px;
}
.listrelated .card .img-thumb {
	width:100%;
}
ul.tags {
	list-style:none;
	padding-left:0;
	margin:3rem 0 3rem 0;
}
ul.tags li {
	display:inline-block;
	font-size:0.9rem;
}
ul.tags li a {
	background:rgba(0,0,0,.05);
	color:rgba(0,0,0,.6);
	border-radius:3px;
	padding:5px 10px;
}
ul.tags li a:hover {
	background:rgba(0,0,0,.07);
	text-decoration:none;
}
.margtop3rem {
	margin-top:3rem;
}
.sep {
	height:1px;
	width:20px;
	background:#999;
	margin:0px auto;
	margin-bottom:1.2rem;
}
.btn.follow {
	border-color:#02B875;
	color:#1C9963;
	padding:3px 10px;
	text-align:center;
	border-radius:999em;
	font-size:0.85rem;
	display:inline-block;
}
.btn.subscribe {
	background-color:#1C9963;
	border-color:#1C9963;
	color:rgba(255,255,255,1);
	fill:rgba(255,255,255,1);
	border-radius:30px;
	font-size:0.85rem;
	margin-left:10px;
	font-weight:600;
	text-transform:uppercase;
}
.post-top-meta .btn.follow {
	margin-left:5px;
	margin-top:-4px;
}
.alertbar {
	box-shadow:0 -3px 10px 0 rgba(0,0,0,.0785);
	position:fixed;
	bottom:0;
	left:0;
	background-color:#fff;
	width:100%;
	padding:14px 0;
	z-index:1;
	 display:none;
}
.alertbar img {
	    max-height: 30px;
}
.form-control::-webkit-input-placeholder {
	color:rgba(0,0,0,.3);
}
.form-control:-moz-placeholder {
	color:rgba(0,0,0,.3);
}
.form-control::-moz-placeholder {
	color:rgba(0,0,0,.3);
}
.form-control:-ms-input-placeholder {
	color:rgba(0,0,0,.3);
}
.form-control::-ms-input-placeholder {
	color:rgba(0,0,0,.3);
}
.authorpage h1 {
	font-weight:700;
	font-size:30px;
}
.post-top-meta.authorpage .author-thumb {
	float:none;
}
.authorpage .author-description {
	font-size:1rem;
	color:rgba(0,0,0,.6);
}
.post-top-meta.authorpage .btn.follow {
	padding:7px 20px;
	margin-top:10px;
	margin-left:0;
	font-size:0.9rem;
}
.graybg.authorpage {
	border-top:1px solid #f0f0f0;
	padding:40px 0 10px;
}
.authorpostbox {
	width:760px;
	margin:0px auto;
	margin-bottom:1.5rem;
	max-width:100%;
}
.authorpostbox .img-thumb {
	width:100%;
}
.sociallinks {
	margin:1rem 0;
}
.sociallinks a {
	background:#666;
	color:#fff;
	width:22px;
	height:22px;
	display:inline-block;
	text-align:center;
	line-height:22px;
	border-radius:50%;
	font-size:12px;
}
.h1,.h2,.h3,.h4,.h5,.h6,h1,h2,h3,h4,h5,h6 {
	font-family:-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;
}
.article-post .h1,.article-post .h2,.article-post .h3,.article-post .h4,.article-post .h5,.article-post .h6,.article-post h1,.article-post h2,.article-post h3,.article-post h4,.article-post h5,.article-post h6 {
	font-weight:700;
	margin-bottom:1.5rem;
}
hr {
	margin-top:1.5rem;
	margin-bottom:1.5rem;
}
.greenme {
	color:#02b875;
	fill:#02b875;
}
.share a:hover {
	text-decoration:none;
	color:#02b875;
}
img {
	max-width:100%;
}
pre {
	margin-bottom:1.5rem;
}
pre {
	font-size:0.90rem;
	display:block;
	background:#c8ffe1;
	padding:10px;
}
#comments {
	margin-top:3rem;
	margin-bottom:1.5rem;
}
.read-next-divider {
	position:relative;
	display:-ms-flexbox;
	display:flex;
	-ms-flex-pack:center;
	justify-content:center;
	height:55px;
}
.read-next-divider svg {
	width:40px;
	fill:transparent;
	stroke:#fff;
	stroke-width:.5px;
	stroke-opacity:.65;
}
.read-next-card-header-title {
	margin:0;
	padding:0 20px;
	color:#fff;
	font-size:1.3rem;
	line-height:1.2em;
	letter-spacing:1px;
}
.read-next-card-header-sitetitle {
		display:block;
	font-size:1.1rem;
	line-height:1.3em;
	opacity:.8;
	font-weight:300;
	margin-bottom:10px;
}
.read-next-card-content li {
	margin:0;
	padding:0;
	font-size:1rem;
	line-height:1.25em;
	font-weight:200;
	letter-spacing:-.5px;
}
.read-next-card-content li a {
	display:block;
	padding:20px 0;
	border-bottom:1px solid hsla(0,0%,100%,.3);
	color:#fff;
	font-weight:500;
	vertical-align:top;
	transition:opacity .3s ease;
}
.read-next-card-footer {
	position:relative;
	margin:15px 0 3px;
	text-align:center;
}
.read-next-card {
	padding:25px;
	color:#fff;
	border-radius:5px;
	box-shadow:8px 14px 38px rgba(39,44,49,.06),1px 3px 8px rgba(39,44,49,.03);
	background: #485563;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #29323c, #485563);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #29323c, #485563); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */

}
.read-next-card-content ul {
	padding-left:20px;
	list-style:none;
}
.read-next-card-header-title a {
	color:#fff;
	font-weight:300;
	text-decoration:none;
}
.read-next-card-header {
	position:relative;
	padding-top:10px;
		padding-bottom:20px;
	text-align:center;
}
.read-next-card-content {
	position:relative;
	-ms-flex-positive:1;
	flex-grow:1;
	display:-ms-flexbox;
	display:flex;
	font-size:1.0rem;
}
.padleft0 {
		padding-left:0;
}
.alertbar .form-group,.alertbar form {
	margin-bottom:0rem;
	display:inline;
		 margin-left:5px;
}
.alertbar .subscribe-email {
	padding:7px 10px;
	border:1px solid rgba(0,0,0,0.2);
	border-radius:3px;
	font-size:0.9rem;
}
.alertbar [type=submit] {
background: #1c9963;
    border-top-right-radius: 3px;
    border-bottom-right-radius: 3px;
    color: #fff;
    font-size: 1rem;
    margin-left: -20px;
    padding: 6px 9px;
    border: 1px solid #1c9963;
    border-top: 0;
}
@media (max-width:1024px) {
	.alertbar form  {
		display: block;
	}
}
.masonrygrid.row {
	margin-left:-10px;
	margin-right:-10px;
}
.section-title span.navigation {
	float:right;
	font-size:0.93rem;
	margin-top:10px;
}
span.navigation {
	display:inline-block;
	font-size:0.93rem;
	font-weight:700;
}
.homecover {
	background-size:cover;
	padding:10rem 0rem;
	color:#fff;
	margin-bottom:2rem;
	margin-top:-1.5rem;
	background-image:url(../img/blog-cover.jpg);
}
.homecover h1,.homecover .lead {
	display:block;
}
.homecover h1 span,.homecover .lead span {
	background:rgba(0,0,0,0.6);
	padding:3px 20px 3px 20px;
	display:inline-block;
}
.jumbotron.fortags {
	border-radius:0;
	background-image:url(../img/footer-cover.jpg);
	background-size:cover;
}
.jumbotron.fortags a {
	padding:5px 10px 7px;
	background:#222;
	border-radius:30px;
	color:#fff;
	font-weight:600;
	text-transform:lowercase;
	font-size:0.9rem;
}
@media (min-width:768px) {
	.jumbotron.fortags {
		margin-bottom:-50px;
		padding:0;
		height:400px;
	}

	.jumbotron.fortags .col-md-4 {
		background:rgba(0,0,0,0.75);
		color:#fff;
		height:400px;
		margin-left:0;
		padding-left:0;
		padding-top:15%;
	}
	.jumbotron.fortags .col-md-4 h2 {
		font-weight:300;
	}
	.jumbotron.fortags .row {
		margin:0;
	}
}
.bottompagination span.navigation {
	display:block;
	font-size:0.93rem;
	padding:15px 0;
	text-align:center;
	margin-bottom:0;
	margin-top:20px;
	color:#292929;
	border-top:1px solid #ddd;
}
.bottompagination span.navigation a {
	color:#999;
}
.pointerup {
	margin-bottom:-36px;
	margin-left:49%;
	font-size:30px;
}
.pointerup i.fa {
	color:#eaeaea;
}
.bottompagination span.navigation i {
	display:inline-block;
}
.author-template .homecover .authorpage {
	max-width:100%;
	margin:0px auto;
	background:rgba(35,29,29,0.5);
	padding:8.5rem 2rem;
	color:#fff;
}
.author-template .homecover {
	padding:0;
}
.author-template .homecover .post-top-meta span,.author-template .homecover .post-top-meta .author-description {
	color:#fff;
}
.author-template .homecover a:hover {
	color:#ccc;
}
.list-group-item:last-child {
	margin-bottom:0;
	border-bottom-right-radius:0;
	border-bottom-left-radius:0;
}
.list-group-item:first-child {
	border-top-right-radius:0;
	border-top-left-radius:0;
}
.search-results {
	position:fixed;
	top:57px;
	right:0;
	z-index:9;
	width:400px;
	font-size:0.9rem;
	margin-bottom:-1px;
}
.search-results p {
	margin-bottom:0;
	background-color:#fff;
	border:1px solid rgba(0,0,0,.125);
	padding:.75rem 1.25rem;
}
a:hover {
	text-decoration:none;
}
.results-hide {
	display: none;
}
.navbar-toggler {
	z-index:9990;
}
.btn-round {
	border-radius:30px;
}
.form-control, label {
	font-size:1rem;
}
.nofeaturedimage {
    font-size: 18px;
    opacity: 0.4;
    color: #fff;
    position: absolute;
    top: 5%;
    font-style:italic;
    width:90%;
    left:20px;
    right:20px;
    font-family:Georgia;
}
.ghostform label {display: block;}
.ghostform input, .ghostform textarea {width:100%;margin-bottom:15px;}
.ghostform input[type="submit"] {width:auto;}
.ghostform textarea {height:200px;}

</style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<section class="recent-posts">
	<div class="section-title">
	<h2>
	<span class="title"><?php echo e($user->name); ?> Stories</span> 

 <div class="clearfix"></div></h2>
	</div>
	<div class="masonrygrid row listrecent">
<?php $__currentLoopData = $user->posts_paginated; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	


	<div class="col-md-4 grid-item">
	    <div class="card post tag-getting-started">
	        <a href="/<?php echo e($post->slug); ?>">
	            <span class="wrapmaxheight">
	        <img class="img-fluid img-thumb" src="" alt="<?php echo e($post->title); ?>">
	    </span>

	        </a>
	        <div class="card-block">
	            <h2 class="card-title"><a href="/<?php echo e($post->slug); ?>"><?php echo e(ucfirst($post->title)); ?></a></h2>
	            <h4 class="card-text">
	            	<?php echo e(trucnateStringh(strip_tags($post->body))); ?>

	            </h4>
	            <div class="metafooter">
	                <div class="wrapfooter">
	                    <span class="meta-footer-thumb">
	              <img class="author-thumb" src="" alt="Sal" />
	        </span>
	                    <span class="author-meta">
	        <span class="post-name"><a href="#"><a href="index.html">$user->name</a></a></span>
	                    <br/>
	                    <span class="post-date"><time class="post-date" datetime=""> </time> </span><span class="dot"></span><span><a href="../../tag/getting-started/index.html">Getting Started</a></span>
	                    </span>
	                    <span class="post-read-more"><a href="../../the-editor/index.html" title="Read Story"><svg class="svgIcon-use" width="25" height="25" viewbox="0 0 25 25"><path d="M19 6c0-1.1-.9-2-2-2H8c-1.1 0-2 .9-2 2v14.66h.012c.01.103.045.204.12.285a.5.5 0 0 0 .706.03L12.5 16.85l5.662 4.126a.508.508 0 0 0 .708-.03.5.5 0 0 0 .118-.285H19V6zm-6.838 9.97L7 19.636V6c0-.55.45-1 1-1h9c.55 0 1 .45 1 1v13.637l-5.162-3.668a.49.49 0 0 0-.676 0z" fill-rule="evenodd"></path></svg></a></span>
	                </div>
	            </div>
	        </div>
	    </div>

	</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	<div class="clearfix"></div>
</div>
  <div class="bottompagination">
    <div class="pointerup"><i class="fa fa-caret-up"></i></div>
    <span class="navigation" role="navigation">
      <?php echo e($user->posts_paginated->links()); ?>

</span>

  </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>