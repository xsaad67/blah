<?php $__env->startSection('content'); ?>

<?php $__env->startSection('css'); ?>
<style>
        #image-preview {
          width: 100%;
          height: 200px;
          position: relative;
          overflow: hidden;
          background-color: #dadada;
          color: #ecf0f1;
        }
        #image-preview input {
          line-height: 200px;
          font-size: 200px;
          position: absolute;
          opacity: 0;
          z-index: 10;
        }
        #image-preview label {
          position: absolute;
          z-index: 5;
          opacity: 0.8;
          cursor: pointer;
          background-color: #bdc3c7;
          width: 200px;
          height: 50px;
          font-size: 20px;
          line-height: 50px;
          text-transform: uppercase;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          margin: auto;
          text-align: center;
        }

        .yes-image{
            background:url(<?php echo e(is_null($featured_image) ?  "" : "/wp-content/uploads/".$featured_image); ?>);
            background-size:cover;
            background-repeat: no-repeat;
        }
    </style>
<?php $__env->stopSection(); ?>
<div class="container">


   <div class="card text-center">
          <div class="card-header">
           Edit Post
          </div>
         <div class="card-body">
            <div class="container">
                <br>
                    <?php echo $__env->make('messages.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <form class="form-horizontal" method="POST" action="<?php echo e(action('PostController@update',['post' => $post->id])); ?>" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>


                <div class="form-group row">
                      <label for="inputEmail3" class="col-sm-2 col-form-label">Title</label>
                      <div class="col-sm-10">
                        <input type="text" class="form-control" name="title" id="inputEmail3" value="<?php echo e($post->title); ?>"  placeholder="Post Title">
                      </div>
                </div>

               <div class="form-group row">
                      <label for="inputEmail3" class="col-sm-2 col-form-label">Category</label>
                      <div class="col-sm-10">
                        <select class="form-control" name="category">
                            <option value="">Please select a category</option>
                            <?php $__currentLoopData = \App\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>" <?php echo e(($category->id == $post->category_id) ? "selected" : ""); ?>><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                </div>


                 <div class="form-group row">

                    <label for="inputPassword3" class="col-sm-2 col-form-label">Upload Image </label>
                        <div id="image-preview" class='col-md-10 <?php echo e(is_null($featured_image) ? "" : "yes-image"); ?> '>
                          <label for="image-upload" id="image-label">Choose File</label>
                          <input type="file" name="featured" id="image-upload" />
                        </div>

                    </div>


                    <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">Body </label>

                    <div class="col-md-10">
                        <textarea name="body" id="body"><?php echo $post->body; ?></textarea>
                    </div>
                    </div>

                       

                        <div class="form-group row">
                            <div class="col-md-6 offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Update Post
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>

<script src="<?php echo e(asset('ckeditor/ckeditor.js')); ?>"></script>
<script type="text/javascript" src="http://opoloo.github.io/jquery_upload_preview/assets/js/jquery.uploadPreview.js"></script>
<script>
     CKEDITOR.replace( 'body' );
</script>

<script type="text/javascript">
jQuery(document).ready(function() {
  
  jQuery.uploadPreview({
    input_field: "#image-upload",
    preview_box: "#image-preview",
    label_field: "#image-label"
  });
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>