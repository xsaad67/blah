

<?php $__env->startSection('css'); ?>
<style>
  .listfeaturedtag h4.card-text, .listrecent h4.card-text {
    color: rgba(0,0,0,.44);
    font-size: 0.95rem;
    line-height: 1.4;
    font-weight: 400;
}
</style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
        
<div class="mainheading  homecover "  style="background-image:url(<?php echo e(is_null($category->image) ? ("wp-content/uploads/categories/".$category->image) : asset("wp-content/uploads/categories/default.jpg")); ?>);" >
			<div class="row post-top-meta authorpage">
  				<div class="col-md-12 col-xs-12">
              <h1 class="text-center"><?php echo e($category->name); ?></h1>
  				</div>
  			
			</div>
</div>


<section class="recent-posts">
	<div class="section-title">
		<h2><span class="title"><?php echo e($category->name); ?>'s Stories</span> 

 <div class="clearfix"></div>                                                                                                         
</div>
	<div class="masonrygrid row listrecent">

<?php $__currentLoopData = $category->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-4 grid-item">
      <div class="card post tag-getting-started">
      <a href="/">
        <span class="wrapmaxheight">
            <img class="img-fluid img-thumb" src="">
        </span>
      
      </a>
      <div class="card-block">
        <h2 class="card-title"><a href="/<?php echo e($category->slug); ?>/<?php echo e($post->slug); ?>"><?php echo e($post->title); ?></a></h2>
        <h4 class="card-text"><?php echo e(trucnateStringh($post->body)); ?></h4>
        <div class="metafooter">
          <div class="wrapfooter">
            <span class="meta-footer-thumb">
                  <img class="author-thumb" src="<?php echo e(is_null($post->user->image)  ? asset("wp-content/uploads/user/default.png") :  asset("wp-content/uploads/user/".$post->user->image)); ?>" alt="<?php echo e($post->user->name); ?>}" />
            </span>
            <span class="author-meta">
            <span class="post-name">
              <a href=""><a href="index.html"><?php echo e($post->user->name); ?></a></a></span><br/>
            <span class="post-date">
              <time class="post-date" datetime="<?php echo e($post->created_at); ?>"> <?php echo e($post->created_at->diffForHumans()); ?>  </time> 
            </span>
            <span class="dot">
              
            </span>
              <span class="readingtime"><?php echo e(wordToMinutes($post->body)); ?> min read</span>

            </span>
         
          </div>
        </div>
      </div>
    </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			
</div>

	<div class="clearfix"></div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>