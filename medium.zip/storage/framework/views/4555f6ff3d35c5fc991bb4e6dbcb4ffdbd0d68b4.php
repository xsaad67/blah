<?php $__env->startSection('css'); ?>

    <style>

.help-block > strong{ color:red; text-align:left; }
        .card-body {
            -webkit-box-flex: 1;
            -ms-flex: 1 1 auto;
            flex: 1 1 auto;
            padding: 1.25rem;
        }


        #image-preview {
          width: 100%;
          height: 200px;
          position: relative;
          overflow: hidden;
          background-color: #dadada;
          color: #ecf0f1;
        }
        #image-preview input {
          line-height: 200px;
          font-size: 200px;
          position: absolute;
          opacity: 0;
          z-index: 10;
        }
        #image-preview label {
          position: absolute;
          z-index: 5;
          opacity: 0.8;
          cursor: pointer;
          background-color: #bdc3c7;
          width: 200px;
          height: 50px;
          font-size: 20px;
          line-height: 50px;
          text-transform: uppercase;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          margin: auto;
          text-align: center;
        }
    </style>

<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>

<div class="col-md-12">
  
</div>
<div class="card text-center">
          <div class="card-header">
            Create Post
          </div>
          <div class="card-body">
            <div class="container">

              <?php if(session()->has('success')): ?>
                  <div class="alert alert-success">
                      <?php echo e(session()->get('success')); ?>

                  </div>
              <?php endif; ?>
           <form class="form-horizontal" method="POST" action="<?php echo e(action('PostController@store')); ?>" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>


                <div class="form-group row">
                    <label for="name" class="col-sm-2 col-form-label">Title</label>
                      <div class="col-sm-10">
                       <input id="name" type="text" class="form-control" name="title" value="<?php echo e(old('title')); ?>" autofocus>
                      
                        <?php if($errors->has('title')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('title')); ?></strong>
                            </span>
                        <?php endif; ?>

                      </div>
                        
                </div>




                 <div class="form-group row">

                    <label for="inputPassword3" class="col-sm-2 col-form-label">Upload Image</label>
                        <div id="image-preview" class="col-md-10">
                          <label for="image-upload" id="image-label">Choose File</label>
                          <input type="file" name="image" id="image-upload" />
                        </div>

                    </div>
                
                  <div class="form-group row">

                    <label for="inputPassword3" class="col-sm-2 col-form-label">Category</label>
                        <div  class="col-md-8">
                          <select name="category" class="form-control">
                            <option value="">Select a Category</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>

                          <?php if($errors->has('category')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('category')); ?></strong>
                            </span>
                          <?php endif; ?>
                        
                        </div>

                        <div class="col-md-2">
                          <a href="/create-category" id="create_cat" class="btn btn-primary" >Create Category</a>
                        </div>

                    </div>


                        <div class="form-group row">
                                <label for="inputPassword3" class="col-sm-2 col-form-label">Body</label>

                            <div class="col-md-10">
                                <textarea name="body" id="body"><?php echo old('body'); ?></textarea>

                              <?php if($errors->has('body')): ?>
                                  <span class="help-block">
                                      <strong><?php echo e($errors->first('body')); ?></strong>
                                  </span>
                              <?php endif; ?>
                              
                            </div>
                        </div>

                       

                   <div class="form-group row">
                      <div class="offset-sm-2 col-sm-9">
                        <button type="submit" class="btn btn-primary ">Create Post</button>
                      </div>
                    </div>
                    </form>
            </div>
          </div>
        
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
<script type="text/javascript" src="http://opoloo.github.io/jquery_upload_preview/assets/js/jquery.uploadPreview.js"></script>
<script src="<?php echo e(asset('ckeditor/ckeditor.js')); ?>"></script>

<script>
jQuery(document).ready(function() {

// $("#addCategory").click(function(){
//   var categoryName = $("#catName").val();
//   var isPublished = $("#isPublished").val();
//   var _token = '<?php echo e(csrf_token()); ?>';

//     $.ajaxSetup({
//       headers: {
//           'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
//       }
//   });

//    $.ajax({
//              type:'POST',
//              url:'/post-category',
//              dataType: 'JSON', 
//              data:"{'_token':'" + _token+ "', 'name':'" + categoryName+ "', 'published':'" + isPublished+ "'}",
//              success:function(data){
//                 $("#msg").html(data.msg);
//              }
//           });

// })
  
 
 CKEDITOR.replace('body', {
      customConfig : 'config.js' ,  
      filebrowserUploadUrl: '<?php echo e(route('upload-image',['_token' => csrf_token() ])); ?>'
});


  jQuery.uploadPreview({
    input_field: "#image-upload",
    preview_box: "#image-preview",
    label_field: "#image-label"
  });
});

</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>