<?php

namespace Tests\Unit;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;

class ExampleTest extends TestCase
{
  
    public function testBasicTest()
    {
        $this->assertTrue(true);
    }
}
